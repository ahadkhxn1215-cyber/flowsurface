use crate::{
    Event, Kline, PushFrequency, TickerInfo, Timeframe, UnixMs,
    adapter::limiter::FixedWindowRateLimiterConfig,
    adapter::{KlinePage, MarketKind, StreamTicksize},
    depth::DepthPayload,
    unit::{MinTicksize, qty::RawQtyUnit},
};

use super::{AdapterError, HttpHub, RequestPort};
use std::time::Duration;

pub mod fetch;
pub mod stream;

const API_DOMAIN: &str = "https://api.hyperliquid.xyz";
const WS_DOMAIN: &str = "api.hyperliquid.xyz";
const MAX_DECIMALS_PERP: u8 = 6;
const SIG_FIG_LIMIT: i32 = 5;

const LIMIT: usize = 1200;
const REFILL_RATE: Duration = Duration::from_secs(60);
const LIMITER_BUFFER_PCT: f32 = 0.05;

const _MAX_DECIMALS_SPOT: u8 = 8;

const MULTS_OVERFLOW: &[u16] = &[1, 10, 20, 50, 100, 1000, 10000];
const MULTS_FRACTIONAL: &[u16] = &[1, 2, 5, 10, 100, 1000];

// safe intersection when base tick is exactly 1 (cannot disambiguate boundary case)
const MULTS_SAFE: &[u16] = &[1, 10, 100, 1000];

/// Allowed multipliers based on observed Hyperliquid tick rules.
pub fn allowed_multipliers_for_min_tick(min_ticksize: MinTicksize) -> &'static [u16] {
    if min_ticksize.power < 0 {
        // int_digits <= 4 (fractional/boundary region)
        MULTS_FRACTIONAL
    } else if min_ticksize.power > 0 {
        MULTS_OVERFLOW
    } else {
        // min tick == 1: could be exactly 5 digits or overflow (>=6).
        MULTS_SAFE
    }
}

fn raw_qty_unit_from_market_type(market: MarketKind) -> RawQtyUnit {
    match market {
        MarketKind::Spot | MarketKind::LinearPerps | MarketKind::InversePerps => RawQtyUnit::Base,
    }
}

#[derive(Debug, Clone, Copy)]
pub struct HyperliquidConfig {
    pub limit: usize,
    pub refill_rate: Duration,
    pub limiter_buffer_pct: f32,
}

impl Default for HyperliquidConfig {
    fn default() -> Self {
        Self {
            limit: LIMIT,
            refill_rate: REFILL_RATE,
            limiter_buffer_pct: LIMITER_BUFFER_PCT,
        }
    }
}

impl HyperliquidConfig {
    fn limiter_config(self) -> FixedWindowRateLimiterConfig {
        FixedWindowRateLimiterConfig::new(
            self.limit,
            self.refill_rate,
            self.limiter_buffer_pct,
            reqwest::StatusCode::TOO_MANY_REQUESTS,
        )
    }
}

pub type HyperliquidLimiter = crate::adapter::limiter::FixedWindowRateLimiter;

type HyperliquidCommand = super::FetchCommand<MarketKind>;

#[derive(Clone)]
pub struct HyperliquidHandle {
    request_port: RequestPort<HyperliquidCommand>,
    proxy_cfg: Option<crate::proxy::Proxy>,
}

impl HyperliquidHandle {
    pub fn new(
        client: reqwest::Client,
        proxy_cfg: Option<&crate::proxy::Proxy>,
    ) -> Result<Self, AdapterError> {
        let worker = Worker::new(client)?;
        let request_port = super::spawn_fetch_worker(worker);

        Ok(Self {
            request_port,
            proxy_cfg: proxy_cfg.cloned(),
        })
    }

    pub async fn fetch_ticker_metadata(
        &self,
        market: MarketKind,
    ) -> Result<super::TickerMetadataMap, AdapterError> {
        self.request_port
            .request(move |reply| HyperliquidCommand::TickerMetadata {
                market_scope: market,
                reply,
            })
            .await
    }

    pub async fn fetch_ticker_stats(
        &self,
        market: MarketKind,
    ) -> Result<super::TickerStatsMap, AdapterError> {
        self.request_port
            .request(move |reply| HyperliquidCommand::TickerStats {
                market_scope: market,
                reply,
            })
            .await
    }

    pub async fn fetch_klines(
        &self,
        ticker: TickerInfo,
        timeframe: Timeframe,
        range: Option<(UnixMs, UnixMs)>,
    ) -> Result<Vec<Kline>, AdapterError> {
        self.request_port
            .request(move |reply| HyperliquidCommand::Klines {
                ticker,
                timeframe,
                range,
                reply,
            })
            .await
    }

    pub async fn fetch_klines_page(
        &self,
        ticker: TickerInfo,
        timeframe: Timeframe,
        from: UnixMs,
        to: UnixMs,
    ) -> Result<KlinePage, AdapterError> {
        self.request_port
            .request(move |reply| HyperliquidCommand::KlinePage {
                ticker,
                timeframe,
                from,
                to,
                reply,
            })
            .await
    }

    pub async fn fetch_depth_snapshot(
        &self,
        ticker: crate::Ticker,
    ) -> Result<DepthPayload, AdapterError> {
        self.request_port
            .request(move |reply| HyperliquidCommand::DepthSnapshot { ticker, reply })
            .await
    }

    pub fn connect_depth_stream(
        self,
        ticker_info: TickerInfo,
        depth_aggr: StreamTicksize,
        push_freq: PushFrequency,
    ) -> impl futures::Stream<Item = Event> {
        let proxy_cfg = self.proxy_cfg.clone();
        stream::connect_depth_stream(self, ticker_info, depth_aggr, push_freq, proxy_cfg)
    }

    pub fn connect_trade_stream(
        self,
        tickers: Vec<TickerInfo>,
        market_type: MarketKind,
    ) -> impl futures::Stream<Item = Event> {
        stream::connect_trade_stream(tickers, market_type, self.proxy_cfg)
    }

    pub fn connect_kline_stream(
        self,
        streams: Vec<(TickerInfo, Timeframe)>,
        market_type: MarketKind,
    ) -> impl futures::Stream<Item = Event> {
        stream::connect_kline_stream(streams, market_type, self.proxy_cfg)
    }
}

struct Worker {
    hub: HttpHub<HyperliquidLimiter>,
}

impl Worker {
    fn new(client: reqwest::Client) -> Result<Self, AdapterError> {
        let config = HyperliquidConfig::default();

        let limiter = HyperliquidLimiter::new(config.limiter_config());
        let hub = HttpHub::with_client(client, limiter);

        Ok(Self { hub })
    }
}

impl super::FetchCommandHandler<MarketKind> for Worker {
    fn fetch_ticker_metadata(
        &mut self,
        market_scope: MarketKind,
    ) -> futures::future::BoxFuture<'_, Result<super::TickerMetadataMap, AdapterError>> {
        Box::pin(async move { fetch::fetch_ticker_metadata(&mut self.hub, market_scope).await })
    }

    fn fetch_ticker_stats(
        &mut self,
        market_scope: MarketKind,
    ) -> futures::future::BoxFuture<'_, Result<super::TickerStatsMap, AdapterError>> {
        Box::pin(async move { fetch::fetch_ticker_stats(&mut self.hub, market_scope).await })
    }

    fn fetch_klines(
        &mut self,
        ticker_info: TickerInfo,
        timeframe: Timeframe,
        range: Option<(UnixMs, UnixMs)>,
    ) -> futures::future::BoxFuture<'_, Result<Vec<Kline>, AdapterError>> {
        Box::pin(
            async move { fetch::fetch_klines(&mut self.hub, ticker_info, timeframe, range).await },
        )
    }

    fn fetch_klines_page(
        &mut self,
        ticker_info: TickerInfo,
        timeframe: Timeframe,
        from: UnixMs,
        to: UnixMs,
    ) -> futures::future::BoxFuture<'_, Result<KlinePage, AdapterError>> {
        Box::pin(async move {
            fetch::fetch_klines_page(&mut self.hub, ticker_info, timeframe, from, to).await
        })
    }

    fn fetch_depth_snapshot(
        &mut self,
        ticker: crate::Ticker,
    ) -> futures::future::BoxFuture<'_, Result<DepthPayload, AdapterError>> {
        Box::pin(async move { fetch::fetch_depth_snapshot(&mut self.hub, ticker).await })
    }
}
