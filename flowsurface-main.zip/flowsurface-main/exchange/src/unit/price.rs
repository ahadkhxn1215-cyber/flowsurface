use super::{MinTicksize, Power10};
use crate::serde_util;
use serde::{Deserialize, Serialize};

/// Fixed atomic unit scale: 10^-ATOMIC_SCALE is the smallest stored fraction.
/// MinTicksize has range [-11, 2], e.g. ATOMIC_SCALE = 11 to represent 10^-11 atomic units.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Ord, PartialOrd, Deserialize, Serialize)]
pub struct Price {
    /// number of atomic units (atomic unit = 10^-ATOMIC_SCALE)
    pub units: i64,
}

impl Price {
    /// number of decimal places of the atomic unit (10^-11)
    const ATOMIC_SCALE: i32 = 11;

    #[inline]
    pub fn to_string<const MIN: i8, const MAX: i8>(self, precision: Power10<MIN, MAX>) -> String {
        let mut out = String::with_capacity(24);
        self.fmt_into(precision, &mut out).unwrap();
        out
    }

    #[inline]
    pub fn fmt_into<const MIN: i8, const MAX: i8, W: core::fmt::Write>(
        self,
        precision: Power10<MIN, MAX>,
        out: &mut W,
    ) -> core::fmt::Result {
        let scale_u = Self::ATOMIC_SCALE as u32;

        // number of atomic units for the given decade step: 10^(ATOMIC_SCALE + power)
        let exp = (Self::ATOMIC_SCALE + precision.power as i32) as u32;
        debug_assert!(Self::ATOMIC_SCALE + precision.power as i32 >= 0);
        let unit = 10i64
            .checked_pow(exp)
            .expect("Price::to_string unit overflow");

        let rounded_units = Self::round_units_half_away(self.units, unit);

        let decimals: u32 = if precision.power < 0 {
            ((-precision.power) as u32).min(scale_u)
        } else {
            0
        };

        if rounded_units < 0 {
            core::fmt::Write::write_char(out, '-')?;
        }
        let abs_u = rounded_units.unsigned_abs();

        let scale_pow = 10u64.pow(scale_u);
        let int_part = abs_u / scale_pow;
        write!(out, "{}", int_part)?;

        if decimals == 0 {
            return Ok(());
        }

        let frac_div = 10u64.pow(scale_u - decimals);
        let frac_part = (abs_u % scale_pow) / frac_div;
        write!(out, ".{:0width$}", frac_part, width = decimals as usize)
    }

    /// Lossy: convert price to f32, may lose precision if going beyond `ATOMIC_SCALE`
    pub fn to_f32_lossy(self) -> f32 {
        self.to_f64() as f32
    }

    /// Create Price from f32 (widens to f64, then rounds to nearest atomic unit)
    pub fn from_f32(v: f32) -> Self {
        Self::from_f64(v as f64)
    }

    /// Convert price to f64.  f64 has ~15 significant digits.
    pub fn to_f64(self) -> f64 {
        let scale = 10f64.powi(Self::ATOMIC_SCALE);
        (self.units as f64) / scale
    }

    /// Create Price from f64 (rounds to nearest atomic unit).
    pub fn from_f64(v: f64) -> Self {
        let scale = 10f64.powi(Self::ATOMIC_SCALE);
        let u = (v * scale).round() as i64;
        Self { units: u }
    }

    /// Round `units` to the nearest multiple of `unit`, half away from zero,
    /// saturating to the i64 range instead of wrapping at the extremes. Runs
    /// in u64 so extreme (saturating) magnitudes can never overflow.
    fn round_units_half_away(units: i64, unit: i64) -> i64 {
        let half = unit / 2;
        let mag = units.unsigned_abs();
        let rounded_mag = ((mag + half as u64) / unit as u64) * unit as u64;
        if units >= 0 {
            rounded_mag.min(i64::MAX as u64) as i64
        } else if rounded_mag > (i64::MAX as u64) + 1 {
            i64::MIN
        } else {
            (rounded_mag as i64).wrapping_neg()
        }
    }

    pub fn round_to_step(self, step: PriceStep) -> Self {
        let unit = step.units;
        if unit <= 1 {
            return self;
        }
        Self {
            units: Self::round_units_half_away(self.units, unit),
        }
    }

    /// Floor to multiple of an arbitrary step
    pub fn floor_to_step(self, step: PriceStep) -> Self {
        let unit = step.units;
        if unit <= 1 {
            return self;
        }
        let floored = (self.units.div_euclid(unit)) * unit;
        Self { units: floored }
    }

    /// Ceil to multiple of an arbitrary step
    fn ceil_to_step(self, step: PriceStep) -> Self {
        let unit = step.units;
        if unit <= 1 {
            return self;
        }
        let added = self.units.checked_add(unit - 1).unwrap_or_else(|| {
            if self.units.is_negative() {
                i64::MIN
            } else {
                i64::MAX
            }
        });

        let ceiled = (added.div_euclid(unit)) * unit;
        Self { units: ceiled }
    }

    /// Group with arbitrary step (e.g. sells floor, buys ceil)
    pub fn round_to_side_step(self, is_sell_or_bid: bool, step: PriceStep) -> Self {
        if is_sell_or_bid {
            self.floor_to_step(step)
        } else {
            self.ceil_to_step(step)
        }
    }

    /// Create Price from raw atomic units (no rounding)
    pub fn from_units(units: i64) -> Self {
        Self { units }
    }

    /// Difference of two prices, saturating instead of panicking on overflow
    /// (mirrors `i64::saturating_sub`).
    pub fn saturating_sub(self, rhs: Self) -> Self {
        Self {
            units: self.units.saturating_sub(rhs.units),
        }
    }

    /// Normalized position of `self` within `[low, high]`: `0.0` at `low`,
    /// `1.0` at `high`. Returns `0.0` for an empty range.
    pub fn ratio_in_range(self, low: Self, high: Self) -> f64 {
        let range = high.units.saturating_sub(low.units);
        if range == 0 {
            0.0
        } else {
            self.units.saturating_sub(low.units) as f64 / range as f64
        }
    }

    /// Returns the atomic-unit count that corresponds to one min tick (min_tick / atomic_unit)
    pub fn min_tick_units(min_tick: MinTicksize) -> i64 {
        let exp = Self::ATOMIC_SCALE + (min_tick.power as i32);
        assert!(exp >= 0, "ATOMIC_SCALE must be >= -min_tick.power");
        10i64
            .checked_pow(exp as u32)
            .expect("min_tick_units overflowed")
    }

    /// Round this Price to the nearest multiple of the provided min_ticksize
    pub fn round_to_min_tick(self, min_tick: MinTicksize) -> Self {
        let unit = Self::min_tick_units(min_tick);
        if unit <= 1 {
            return self;
        }
        Self {
            units: Self::round_units_half_away(self.units, unit),
        }
    }

    pub fn checked_add_steps(self, steps: i64, step: PriceStep) -> Option<Self> {
        let delta = steps.checked_mul(step.units)?;
        self.units.checked_add(delta).map(Self::from_units)
    }

    /// Number of step increments between low..=high (inclusive), or None if invalid.
    pub fn steps_between_inclusive(low: Price, high: Price, step: PriceStep) -> Option<usize> {
        if high.units < low.units || step.units <= 0 {
            return None;
        }
        let span = i128::from(high.units) - i128::from(low.units);
        usize::try_from(span / i128::from(step.units) + 1).ok()
    }
}

impl std::ops::Add for Price {
    type Output = Self;

    fn add(self, rhs: Self) -> Self::Output {
        Self {
            units: self
                .units
                .checked_add(rhs.units)
                .expect("Price add overflowed"),
        }
    }
}

impl std::ops::Div<i64> for Price {
    type Output = Self;

    fn div(self, rhs: i64) -> Self::Output {
        Self {
            units: self.units.div_euclid(rhs),
        }
    }
}

impl std::ops::Div for Price {
    type Output = f64;

    /// Ratio of two prices as a dimensionless f64.
    /// Both sides share the same atomic scale so this is exact.
    fn div(self, rhs: Self) -> f64 {
        self.units as f64 / rhs.units as f64
    }
}

impl std::ops::Sub for Price {
    type Output = Self;

    fn sub(self, rhs: Self) -> Self::Output {
        Self {
            units: self
                .units
                .checked_sub(rhs.units)
                .expect("Price sub overflowed"),
        }
    }
}

pub fn de_price_from_number<'de, D>(deserializer: D) -> Result<Price, D::Error>
where
    D: serde::Deserializer<'de>,
{
    serde_util::de_number_like_or_object(deserializer, "price", Price::from_f64)
}

#[derive(
    Debug, Default, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Deserialize, Serialize,
)]
pub struct PriceStep {
    /// step size in atomic units (10^-ATOMIC_SCALE)
    pub units: i64,
}

impl PriceStep {
    /// Return the smallest whole-number multiple of this step that fits the range.
    pub fn coarsened_to_fit(self, low: Price, high: Price, max_rows: usize) -> Option<Self> {
        if self.units <= 0 || high < low || max_rows == 0 {
            return None;
        }

        let max_factor = i64::MAX / self.units;
        let max_rows = i128::try_from(max_rows).ok()?;
        let base = i128::from(self.units);
        let low_units = i128::from(low.units).div_euclid(base);
        let high_units = i128::from(high.units).div_euclid(base);
        let span = high_units - low_units;
        let max_difference = max_rows - 1;
        let first_factor = if max_difference == 0 {
            span.checked_add(1)?
        } else {
            span / (max_difference + 1) + 1
        };
        let last_factor = if max_difference == 0 {
            i128::from(max_factor)
        } else {
            (span + max_difference - 1) / max_difference
        }
        .max(1)
        .min(i128::from(max_factor));
        if first_factor > last_factor {
            return None;
        }

        let mut factor = first_factor.max(1);
        while factor <= last_factor {
            let low_row_index = low_units.div_euclid(factor);
            let high_row_index = high_units.div_euclid(factor);
            if high_row_index - low_row_index < max_rows {
                let units = base * factor;
                let low_row = low_row_index * units;
                let high_row = high_row_index * units;
                if i64::try_from(low_row).is_ok() && i64::try_from(high_row).is_ok() {
                    return i64::try_from(units).ok().map(|units| Self { units });
                }
            }

            let next_low = next_quotient_change(low_units, factor, low_row_index);
            let next_high = next_quotient_change(high_units, factor, high_row_index);
            factor = next_low.into_iter().chain(next_high).min()?;
        }

        None
    }

    /// Returns a power-of-two multiple of this step that fits the range.
    pub fn nested_coarsened_to_fit(self, low: Price, high: Price, max_rows: usize) -> Option<Self> {
        let minimum_step = self.coarsened_to_fit(low, high, max_rows)?;
        let factor = u64::try_from(minimum_step.units / self.units)
            .ok()?
            .checked_next_power_of_two()?;
        let mut units = self.units.checked_mul(i64::try_from(factor).ok()?)?;
        let max_rows = i128::try_from(max_rows).ok()?;

        loop {
            let base = i128::from(units);
            let low_row = i128::from(low.units).div_euclid(base);
            let high_row = i128::from(high.units).div_euclid(base);
            if high_row - low_row < max_rows {
                i64::try_from(low_row * base).ok()?;
                i64::try_from(high_row * base).ok()?;
                return Some(Self { units });
            }
            units = units.checked_mul(2)?;
        }
    }

    /// Decimal places needed to represent this step without trailing zeros.
    pub fn decimal_places(self) -> usize {
        let mut units = self.units.unsigned_abs();
        if units == 0 {
            return 0;
        }

        let mut trailing_zeros = 0u32;
        let max = Price::ATOMIC_SCALE as u32;
        while trailing_zeros < max && units.is_multiple_of(10) {
            units /= 10;
            trailing_zeros += 1;
        }

        (max - trailing_zeros) as usize
    }

    /// String form for UI labels, trimming trailing fractional zeros.
    pub fn to_ui_string(self) -> String {
        let mut out = String::with_capacity(24);

        if self.units < 0 {
            out.push('-');
        }

        let abs_u = self.units.unsigned_abs();
        let scale = 10u64.pow(Price::ATOMIC_SCALE as u32);
        let int_part = abs_u / scale;
        out.push_str(&int_part.to_string());

        let frac_raw = abs_u % scale;
        if frac_raw == 0 {
            return out;
        }

        let mut frac = format!("{:0width$}", frac_raw, width = Price::ATOMIC_SCALE as usize);
        while frac.ends_with('0') {
            frac.pop();
        }

        out.push('.');
        out.push_str(&frac);
        out
    }

    /// Lossy: f32 step for UI
    pub fn to_f32_lossy(self) -> f32 {
        self.to_f64_lossy() as f32
    }

    /// f64 step for UI
    pub fn to_f64_lossy(self) -> f64 {
        let scale = 10f64.powi(Price::ATOMIC_SCALE);
        (self.units as f64) / scale
    }
}

fn next_quotient_change(value: i128, divisor: i128, quotient: i128) -> Option<i128> {
    if value >= 0 {
        (quotient > 0).then(|| value / quotient + 1)
    } else {
        let magnitude = -value;
        let positive_quotient = -quotient;
        (positive_quotient > 1).then(|| (magnitude - 1) / (positive_quotient - 1) + 1)
    }
    .filter(|next| *next > divisor)
}

impl<const MIN: i8, const MAX: i8> From<Power10<MIN, MAX>> for PriceStep {
    fn from(v: Power10<MIN, MAX>) -> Self {
        let exp = Price::ATOMIC_SCALE + i32::from(v.power);
        assert!(exp >= 0, "invalid Power10 to PriceStep exponent");

        Self {
            units: 10i64
                .checked_pow(exp as u32)
                .expect("Power10 to PriceStep overflowed"),
        }
    }
}
