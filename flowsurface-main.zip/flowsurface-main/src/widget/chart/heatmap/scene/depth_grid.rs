use data::chart::heatmap::HistoricalDepth;
use exchange::UnixMs;
use exchange::adapter::MarketKind;
use exchange::depth::Depth;
use exchange::unit::{Price, PriceStep, Qty};
use std::sync::Arc;

const Y_MAX_BLOCK_HEIGHT_BINS: u32 = 16;

/// Margin before forcing a full recenter rebuild (fraction of tex_h)
const RECENTER_Y_MARGIN_FRAC: f32 = 0.25;

/// How many aggregated time buckets to keep in the ring buffer horizon.
const GRID_HORIZON_BUCKETS: u32 = 4800;

const GRID_TEX_H: u32 = 2048; // steps around anchor

#[derive(Debug, Clone)]
pub struct GridRing {
    horizon_buckets: u32,
    tex_w: u32,
    tex_h: u32,
    aggr_time_ms: u64,
    last_bucket: Option<i64>,
    y_anchor: Option<Price>,
    bid: Vec<u32>,
    ask: Vec<u32>,
    col_max_bid: Vec<u32>,
    col_max_ask: Vec<u32>,
    steps_per_y_bin: i64,
    full_dirty: bool,
    dirty_cols: Vec<u32>,
    block_max_bid: Vec<u32>,
    block_max_ask: Vec<u32>,
}

impl Default for GridRing {
    fn default() -> Self {
        Self::new()
    }
}

impl GridRing {
    pub fn new() -> Self {
        Self {
            horizon_buckets: GRID_HORIZON_BUCKETS,
            tex_w: 0,
            tex_h: GRID_TEX_H,
            aggr_time_ms: 0,
            last_bucket: None,
            y_anchor: None,
            bid: Vec::new(),
            ask: Vec::new(),
            col_max_bid: Vec::new(),
            col_max_ask: Vec::new(),
            steps_per_y_bin: 1,
            full_dirty: false,
            dirty_cols: Vec::new(),
            block_max_bid: Vec::new(),
            block_max_ask: Vec::new(),
        }
    }

    pub fn bids_len(&self) -> usize {
        self.bid.len()
    }

    pub fn asks_len(&self) -> usize {
        self.ask.len()
    }

    pub fn get_bid(&self, idx: usize) -> Option<u32> {
        self.bid.get(idx).copied()
    }

    pub fn get_ask(&self, idx: usize) -> Option<u32> {
        self.ask.get(idx).copied()
    }

    /// `None` if `idx` is beyond the end of either buffer.
    pub fn get_pair(&self, idx: usize) -> Option<(u32, u32)> {
        Some((self.get_bid(idx)?, self.get_ask(idx)?))
    }

    #[inline]
    pub fn tex_w(&self) -> u32 {
        self.tex_w
    }

    #[inline]
    pub fn tex_h(&self) -> u32 {
        self.tex_h
    }

    /// Current y-anchor used for mapping (if any).
    #[inline]
    pub fn y_anchor_price(&self) -> Option<Price> {
        self.y_anchor
    }

    /// Force the next `build_scene_upload_plan()` to produce a full texture upload.
    /// Useful when GPU resources were recreated (e.g. window hidden/re-shown).
    #[inline]
    pub fn force_full_upload(&mut self) {
        self.mark_full_dirty();
    }

    /// Current y-binning in steps.
    #[inline]
    pub fn steps_per_y_bin(&self) -> i64 {
        self.steps_per_y_bin.max(1)
    }

    /// Rebuild the entire ring grid from `HistoricalDepth` for the time window
    /// [oldest_time, latest_time] (bucketed by `aggr_time_ms`) using the current view binning.
    ///
    /// This is intended for interaction spikes (zoom/pan changes), not per-frame.
    pub fn rebuild_from_historical(
        &mut self,
        hist: &HistoricalDepth,
        oldest_time: u64,
        latest_time: u64,
        base_price: Price,
        step: PriceStep,
        steps_per_y_bin: i64,
        qty_scale: f32,
        highest: Price,
        lowest: Price,
        market_type: &MarketKind,
        size_in_quote_ccy: bool,
        order_size_filter: f32,
    ) {
        if self.aggr_time_ms == 0 || self.tex_w == 0 || self.tex_h == 0 {
            return;
        }

        self.steps_per_y_bin = steps_per_y_bin.max(1);
        self.y_anchor = Some(base_price);

        self.clear_all();
        self.last_bucket = None;

        let step_units = step.units.max(1);
        let half_h = (self.tex_h as i64) / 2;

        // Clamp time window to bucket boundaries.
        let aggr = self.aggr_time_ms.max(1);
        let oldest_time = (oldest_time / aggr) * aggr;
        let latest_time = (latest_time / aggr) * aggr;
        let oldest_time_unix = UnixMs::new(oldest_time);
        let latest_time_unix = UnixMs::new(latest_time);

        let oldest_bucket: i64 = (oldest_time / aggr) as i64;
        let latest_bucket: i64 = (latest_time / aggr) as i64;

        if latest_bucket < oldest_bucket {
            return;
        }

        let w = self.tex_w as i64;

        for (price, runs) in hist.iter_time_filtered(
            oldest_time_unix,
            latest_time_unix.saturating_add(aggr),
            highest,
            lowest,
        ) {
            // Map price -> y bin (view-relative around base_price).
            let dy_bins: i64 = self.price_delta_y_bins(*price, base_price, step_units);

            let Some(y) = Self::texture_y_index(half_h, dy_bins, self.tex_h) else {
                continue;
            };
            let y = y as usize;

            for run in runs.iter() {
                // Overlap run with [oldest_time, latest_time+aggr)
                let run_start = run.start_time.max(oldest_time_unix).as_u64();
                let run_end_excl = run
                    .until_time
                    .min(latest_time_unix.saturating_add(aggr))
                    .as_u64();
                if run_end_excl <= run_start {
                    continue;
                }

                let b0 = (run_start / aggr) as i64;
                // run_end_excl is exclusive; last bucket touched is (end_excl-1)/aggr
                let b1 = ((run_end_excl - 1) / aggr) as i64;

                let b0 = b0.max(oldest_bucket);
                let b1 = b1.min(latest_bucket);
                if b1 < b0 {
                    continue;
                }

                let q = run.qty;
                if q <= Qty::ZERO {
                    continue;
                }
                if order_size_filter > 0.0 {
                    let order_size = market_type.qty_in_quote_value(q, *price, size_in_quote_ccy);
                    if order_size as f32 <= order_size_filter {
                        continue;
                    }
                }

                let q_u32 = (q.to_f32_lossy() * qty_scale)
                    .round()
                    .clamp(0.0, u32::MAX as f32) as u32;
                if q_u32 == 0 {
                    continue;
                }

                // Fill each bucket column this run covers.
                for bucket in b0..=b1 {
                    let x = (bucket.rem_euclid(w)) as usize;
                    let idx = y * (self.tex_w as usize) + x;

                    if run.is_bid {
                        self.bid[idx] = self.bid[idx].max(q_u32);
                        self.col_max_bid[x] = self.col_max_bid[x].max(q_u32);
                        let by = (y as u32) / Y_MAX_BLOCK_HEIGHT_BINS;
                        let bidx = (by as usize) * (self.tex_w as usize) + x;
                        if bidx < self.block_max_bid.len() {
                            self.block_max_bid[bidx] = self.block_max_bid[bidx].max(q_u32);
                        }
                    } else {
                        self.ask[idx] = self.ask[idx].max(q_u32);
                        self.col_max_ask[x] = self.col_max_ask[x].max(q_u32);
                        let by = (y as u32) / Y_MAX_BLOCK_HEIGHT_BINS;
                        let bidx = (by as usize) * (self.tex_w as usize) + x;
                        if bidx < self.block_max_ask.len() {
                            self.block_max_ask[bidx] = self.block_max_ask[bidx].max(q_u32);
                        }
                    }
                }
            }
        }

        self.last_bucket = Some(latest_bucket);

        // After rebuild, renderer must reupload full texture.
        self.mark_full_dirty();
    }

    pub fn ensure_layout(&mut self, aggr_time_ms: u64) {
        let aggr_time_ms = aggr_time_ms.max(1);

        let tex_w = self.horizon_buckets.max(1).next_power_of_two();

        let needs_realloc = self.aggr_time_ms != aggr_time_ms || self.tex_w != tex_w;
        if !needs_realloc {
            return;
        }

        self.aggr_time_ms = aggr_time_ms;
        self.tex_w = tex_w;
        self.last_bucket = None;

        let len = (self.tex_w as usize) * (self.tex_h as usize);
        self.bid.clear();
        self.ask.clear();
        self.bid.resize(len, 0);
        self.ask.resize(len, 0);

        self.col_max_bid.clear();
        self.col_max_ask.clear();
        self.col_max_bid.resize(self.tex_w as usize, 0);
        self.col_max_ask.resize(self.tex_w as usize, 0);

        let blocks = self.y_block_count() as usize;
        self.block_max_bid.clear();
        self.block_max_ask.clear();
        self.block_max_bid.resize((self.tex_w as usize) * blocks, 0);
        self.block_max_ask.resize((self.tex_w as usize) * blocks, 0);

        // Layout change => full upload required.
        self.mark_full_dirty();
    }

    /// Update the ring for a new snapshot at `rounded_t_ms`.
    pub fn ingest_snapshot(
        &mut self,
        depth: &Depth,
        rounded_t_ms: u64,
        step: PriceStep,
        qty_scale: f32,
        recenter_target: Price,
        steps_per_y_bin: i64,
        market_type: &MarketKind,
        size_in_quote_ccy: bool,
        order_size_filter: f32,
    ) {
        let steps_per_y_bin = steps_per_y_bin.max(1);
        if self.steps_per_y_bin != steps_per_y_bin {
            self.steps_per_y_bin = steps_per_y_bin;
            self.clear_all();
            self.last_bucket = None;
            self.y_anchor = None;

            // Binning change => full upload required.
            self.mark_full_dirty();
        }

        if self.aggr_time_ms == 0 || self.tex_w == 0 || self.tex_h == 0 {
            return;
        }

        let step_units = step.units.max(1);
        let recenter_threshold_bins: u64 = (self.tex_h as u64) / 4;

        match self.y_anchor {
            None => self.y_anchor = Some(recenter_target),
            Some(anchor) => {
                let delta_bins = self.price_delta_y_bins(recenter_target, anchor, step_units);

                if delta_bins.unsigned_abs() > recenter_threshold_bins.max(1) {
                    self.y_anchor = Some(recenter_target);
                    self.clear_all();
                    self.last_bucket = None;

                    // Recentering => full upload required.
                    self.mark_full_dirty();
                }
            }
        }
        let Some(anchor) = self.y_anchor else {
            return;
        };

        let bucket: i64 = (rounded_t_ms / self.aggr_time_ms) as i64;
        let w = self.tex_w as i64;
        let x: u32 = (bucket.rem_euclid(w)) as u32;
        let prev_bucket_opt = self.last_bucket;

        if let Some(prev) = self.last_bucket
            && bucket < prev
        {
            // Drop late/out-of-order snapshots
            return;
        }

        self.advance_and_fill_columns(bucket);

        self.clear_column(x);
        self.scatter_side(
            &depth.bids,
            x,
            anchor,
            step,
            step_units,
            qty_scale,
            true,
            market_type,
            size_in_quote_ccy,
            order_size_filter,
        );
        self.scatter_side(
            &depth.asks,
            x,
            anchor,
            step,
            step_units,
            qty_scale,
            false,
            market_type,
            size_in_quote_ccy,
            order_size_filter,
        );

        if let Some(prev_bucket) = prev_bucket_opt {
            let jump = bucket - prev_bucket;
            if jump > 1 && jump <= self.tex_w as i64 {
                self.retain_current_presence_in_carried_gap(prev_bucket, bucket, x);
            }
        }
    }

    fn price_delta_y_bins(&self, price: Price, anchor: Price, step_units: i64) -> i64 {
        let delta_steps = {
            let step_units = step_units.max(1);
            price.saturating_sub(anchor).units.div_euclid(step_units)
        };

        let steps_per_y_bin = self.steps_per_y_bin.max(1);
        delta_steps / steps_per_y_bin
    }

    fn texture_y_index(half_h: i64, delta_bins: i64, tex_h: u32) -> Option<u32> {
        let y = half_h.checked_add(delta_bins)?;
        (0..i64::from(tex_h)).contains(&y).then_some(y as u32)
    }

    /// Map an absolute bucket index to the ring texture x coordinate.
    /// Returns 0 if the ring is not laid out yet.
    #[inline]
    pub fn ring_x_for_bucket(&self, bucket: i64) -> u32 {
        if self.tex_w == 0 {
            return 0;
        }
        (bucket.rem_euclid(self.tex_w as i64)) as u32
    }

    /// Value for the shader uniform `heatmap_map[1]` (y_start_bin).
    ///
    /// This is the y-bin offset that aligns the texture's internal `y_anchor`
    /// with the current `base_price`.
    #[inline]
    pub fn heatmap_y_start_bin(&self, base_price: Price, step: PriceStep) -> f32 {
        let tex_h = self.tex_h.max(1);
        let half_h = (tex_h as i32) / 2;

        let Some(anchor) = self.y_anchor else {
            return -(half_h as f32);
        };

        let step_units = step.units.max(1);

        // delta_bins = (base - anchor) in y-bins
        let delta_bins: i64 = self.price_delta_y_bins(base_price, anchor, step_units);

        -(half_h as f32) - (delta_bins as f32)
    }

    pub fn upload_to_scene(&mut self, force_full: bool) -> Option<super::HeatmapUpload> {
        let tex_w = self.tex_w();
        let tex_h = self.tex_h();
        if tex_w == 0 || tex_h == 0 {
            return None;
        }

        if force_full {
            self.force_full_upload();
        }

        self.build_scene_upload()
    }

    /// Determines if the grid should be recentered based on distance from current anchor.
    /// Returns true if the target price has drifted beyond the acceptable margin.
    pub fn should_recenter(&self, target: Price, step: PriceStep) -> bool {
        let tex_h = self.tex_h() as i64;
        if tex_h <= 0 {
            return false;
        }

        let Some(anchor) = self.y_anchor_price() else {
            return true; // No anchor set, should recenter
        };

        let step_units = step.units.max(1);

        let delta_bins = self
            .price_delta_y_bins(target, anchor, step_units)
            .unsigned_abs();

        let margin_bins = ((tex_h as f32) * RECENTER_Y_MARGIN_FRAC).round().max(1.0) as u64;

        delta_bins > margin_bins
    }

    /// True if caller should perform a full rebuild-from-historical.
    #[inline]
    pub fn should_full_rebuild(
        &self,
        prev_steps_per_y_bin: i64,
        new_steps_per_y_bin: i64,
        recenter_target: Price,
        step: PriceStep,
        force_full_rebuild: bool,
    ) -> bool {
        let prev = prev_steps_per_y_bin.max(1);
        let next = new_steps_per_y_bin.max(1);
        (prev != next) || force_full_rebuild || self.should_recenter(recenter_target, step)
    }

    /// Time window (ms) required to fill the ring horizon ending at `latest_time_ms`.
    #[inline]
    pub fn horizon_time_window_ms(&self, latest_time_ms: u64, aggr_time_ms: u64) -> (u64, u64) {
        let aggr_time_ms = aggr_time_ms.max(1);
        let horizon_ms = (self.horizon_buckets as u64).saturating_mul(aggr_time_ms);
        let oldest = latest_time_ms.saturating_sub(horizon_ms);
        (oldest, latest_time_ms)
    }

    /// Compute rebuild bounds (highest/lowest prices) for the current texture height.
    ///
    /// These bounds are centered around `anchor` and span half the texture height in bins.
    #[inline]
    pub fn rebuild_price_bounds(
        &self,
        anchor: Price,
        step: PriceStep,
        steps_per_y_bin: i64,
    ) -> (Price, Price) {
        let tex_h_i64 = (self.tex_h.max(1)) as i64;
        let half_bins = tex_h_i64 / 2;

        let step_units = step.units.max(1);
        let steps_per = steps_per_y_bin.max(1);

        let half_steps = half_bins.saturating_mul(steps_per);
        let delta_units = half_steps.saturating_mul(step_units);

        let anchor_u = anchor.units;
        let highest = Price::from_units(anchor_u.saturating_add(delta_units));
        let lowest = Price::from_units(anchor_u.saturating_sub(delta_units));
        (highest, lowest)
    }

    fn y_block_count(&self) -> u32 {
        if self.tex_h == 0 {
            0
        } else {
            self.tex_h.div_ceil(Y_MAX_BLOCK_HEIGHT_BINS)
        }
    }

    fn block_idx(&self, x: u32, block_y: u32) -> usize {
        (block_y as usize) * (self.tex_w as usize) + (x as usize)
    }

    /// Returns `true` once after an internal reset/recenter/layout change that requires
    /// a full texture upload. Consumes the flag.
    fn take_full_dirty(&mut self) -> bool {
        if self.full_dirty {
            self.full_dirty = false;
            self.dirty_cols.clear();
            true
        } else {
            false
        }
    }

    /// Returns the set of x-columns that changed since last call (sorted, deduped).
    /// If the grid is in "full dirty" state, returns an empty vec (caller should full-upload).
    fn drain_dirty_columns(&mut self) -> Vec<u32> {
        if self.full_dirty || self.dirty_cols.is_empty() {
            self.dirty_cols.clear();
            return Vec::new();
        }

        let mut out = std::mem::take(&mut self.dirty_cols);
        out.sort_unstable();
        out.dedup();
        out
    }

    fn mark_full_dirty(&mut self) {
        self.full_dirty = true;
        self.dirty_cols.clear();
    }

    fn mark_dirty(&mut self, x: u32) {
        if !self.full_dirty {
            self.dirty_cols.push(x);
        }
    }

    fn scatter_side(
        &mut self,
        side: &std::collections::BTreeMap<Price, Qty>,
        x: u32,
        anchor: Price,
        step: PriceStep,
        step_units: i64,
        qty_scale: f32,
        is_bid: bool,
        market_type: &MarketKind,
        size_in_quote_ccy: bool,
        order_size_filter: f32,
    ) {
        let half_h = (self.tex_h as i64) / 2;
        let w = self.tex_w as usize;
        let x_usize = x as usize;

        let mut current_price: Option<Price> = None;
        let mut current_qty: Qty = Qty::ZERO;

        let mut flush = |rounded_price: Price, qty_sum: Qty| {
            if qty_sum <= Qty::ZERO {
                return;
            }

            if order_size_filter > 0.0 {
                let order_size =
                    market_type.qty_in_quote_value(qty_sum, rounded_price, size_in_quote_ccy);
                if order_size as f32 <= order_size_filter {
                    return;
                }
            }

            let q = qty_sum.to_f32_lossy();
            let dy_bins = self.price_delta_y_bins(rounded_price, anchor, step_units);

            let Some(y) = Self::texture_y_index(half_h, dy_bins, self.tex_h) else {
                return;
            };

            let q_u32 = (q * qty_scale).round().clamp(0.0, u32::MAX as f32) as u32;
            if q_u32 == 0 {
                return;
            }

            let idx = (y as usize) * w + x_usize;

            if is_bid {
                self.bid[idx] = self.bid[idx].max(q_u32);
                self.col_max_bid[x_usize] = self.col_max_bid[x_usize].max(q_u32);

                let by = y / Y_MAX_BLOCK_HEIGHT_BINS;
                let bidx = (by as usize) * w + x_usize;
                if bidx < self.block_max_bid.len() {
                    self.block_max_bid[bidx] = self.block_max_bid[bidx].max(q_u32);
                }
            } else {
                self.ask[idx] = self.ask[idx].max(q_u32);
                self.col_max_ask[x_usize] = self.col_max_ask[x_usize].max(q_u32);

                let by = y / Y_MAX_BLOCK_HEIGHT_BINS;
                let bidx = (by as usize) * w + x_usize;
                if bidx < self.block_max_ask.len() {
                    self.block_max_ask[bidx] = self.block_max_ask[bidx].max(q_u32);
                }
            }
        };

        for (price, qty) in side.iter() {
            let rounded = price.round_to_side_step(is_bid, step);

            if Some(rounded) == current_price {
                current_qty += *qty;
            } else {
                if let Some(p) = current_price {
                    flush(p, current_qty);
                }
                current_price = Some(rounded);
                current_qty = *qty;
            }
        }

        if let Some(p) = current_price {
            flush(p, current_qty);
        }
    }

    fn extract_bid_column(&self, x: u32) -> Vec<u32> {
        self.extract_column_impl(x, true)
    }

    fn extract_ask_column(&self, x: u32) -> Vec<u32> {
        self.extract_column_impl(x, false)
    }

    fn copy_column(&mut self, from_x: u32, to_x: u32) {
        if from_x == to_x {
            return;
        }
        let w = self.tex_w as usize;
        let from = from_x as usize;
        let to = to_x as usize;

        for y in 0..(self.tex_h as usize) {
            let from_idx = y * w + from;
            let to_idx = y * w + to;
            self.bid[to_idx] = self.bid[from_idx];
            self.ask[to_idx] = self.ask[from_idx];
        }

        if from < self.col_max_bid.len() && to < self.col_max_bid.len() {
            self.col_max_bid[to] = self.col_max_bid[from];
        }
        if from < self.col_max_ask.len() && to < self.col_max_ask.len() {
            self.col_max_ask[to] = self.col_max_ask[from];
        }

        // copy y-block maxima
        let blocks = self.y_block_count();
        for by in 0..blocks {
            let fi = self.block_idx(from_x, by);
            let ti = self.block_idx(to_x, by);
            if fi < self.block_max_bid.len() && ti < self.block_max_bid.len() {
                self.block_max_bid[ti] = self.block_max_bid[fi];
                self.block_max_ask[ti] = self.block_max_ask[fi];
            }
        }

        self.mark_dirty(to_x);
    }

    fn recompute_column_stats(&mut self, x: u32) {
        let w = self.tex_w as usize;
        let h = self.tex_h as usize;
        let x_usize = x as usize;

        if w == 0 || h == 0 || x_usize >= w {
            return;
        }

        let mut col_max_bid = 0u32;
        let mut col_max_ask = 0u32;

        if x_usize < self.col_max_bid.len() {
            self.col_max_bid[x_usize] = 0;
        }
        if x_usize < self.col_max_ask.len() {
            self.col_max_ask[x_usize] = 0;
        }

        let blocks = self.y_block_count();
        for by in 0..blocks {
            let i = self.block_idx(x, by);
            if i < self.block_max_bid.len() {
                self.block_max_bid[i] = 0;
                self.block_max_ask[i] = 0;
            }
        }

        for y in 0..h {
            let idx = y * w + x_usize;
            let bid_v = self.bid[idx];
            let ask_v = self.ask[idx];

            col_max_bid = col_max_bid.max(bid_v);
            col_max_ask = col_max_ask.max(ask_v);

            let by = (y as u32) / Y_MAX_BLOCK_HEIGHT_BINS;
            let bidx = self.block_idx(x, by);
            if bidx < self.block_max_bid.len() {
                self.block_max_bid[bidx] = self.block_max_bid[bidx].max(bid_v);
                self.block_max_ask[bidx] = self.block_max_ask[bidx].max(ask_v);
            }
        }

        if x_usize < self.col_max_bid.len() {
            self.col_max_bid[x_usize] = col_max_bid;
        }
        if x_usize < self.col_max_ask.len() {
            self.col_max_ask[x_usize] = col_max_ask;
        }
    }

    /// Carries only if the presence in the new column matches the current column, otherwise clears it.
    fn retain_current_presence_in_carried_gap(
        &mut self,
        prev_bucket: i64,
        new_bucket: i64,
        current_x: u32,
    ) {
        if new_bucket <= prev_bucket + 1 || self.tex_w == 0 || self.tex_h == 0 {
            return;
        }

        let w = self.tex_w as usize;
        let h = self.tex_h as usize;
        let current_x_usize = current_x as usize;

        let mut current_has_bid = vec![false; h];
        let mut current_has_ask = vec![false; h];

        for y in 0..h {
            let row = y * w;
            current_has_bid[y] = self.bid[row + current_x_usize] > 0;
            current_has_ask[y] = self.ask[row + current_x_usize] > 0;
        }

        for b in (prev_bucket + 1)..new_bucket {
            let x = (b.rem_euclid(self.tex_w as i64)) as u32;
            let x_usize = x as usize;
            let mut changed = false;

            for y in 0..h {
                let row = y * w;
                let idx = row + x_usize;

                if !current_has_bid[y] && self.bid[idx] != 0 {
                    self.bid[idx] = 0;
                    changed = true;
                }

                if !current_has_ask[y] && self.ask[idx] != 0 {
                    self.ask[idx] = 0;
                    changed = true;
                }
            }

            if changed {
                self.recompute_column_stats(x);
                self.mark_dirty(x);
            }
        }
    }

    fn clear_column(&mut self, x: u32) {
        let w = self.tex_w as usize;
        let x_usize = x as usize;

        for y in 0..(self.tex_h as usize) {
            let idx = y * w + x_usize;
            self.bid[idx] = 0;
            self.ask[idx] = 0;
        }

        if x_usize < self.col_max_bid.len() {
            self.col_max_bid[x_usize] = 0;
        }
        if x_usize < self.col_max_ask.len() {
            self.col_max_ask[x_usize] = 0;
        }

        // clear y-block maxima
        let blocks = self.y_block_count();
        for by in 0..blocks {
            let i = self.block_idx(x, by);
            if i < self.block_max_bid.len() {
                self.block_max_bid[i] = 0;
                self.block_max_ask[i] = 0;
            }
        }

        self.mark_dirty(x);
    }

    fn clear_all(&mut self) {
        self.bid.fill(0);
        self.ask.fill(0);
        self.col_max_bid.fill(0);
        self.col_max_ask.fill(0);

        self.block_max_bid.fill(0);
        self.block_max_ask.fill(0);

        // Whole texture changed => force full upload.
        self.mark_full_dirty();
    }

    fn extract_column_impl(&self, x: u32, is_bid: bool) -> Vec<u32> {
        let w = self.tex_w as usize;
        let h = self.tex_h as usize;
        let x = x as usize;

        let grid = if is_bid { &self.bid } else { &self.ask };

        let mut out = vec![0u32; h];
        if w == 0 || h == 0 || grid.len() != w * h || x >= w {
            return out;
        }

        for y in 0..h {
            out[y] = grid[y * w + x];
        }
        out
    }

    fn advance_and_fill_columns(&mut self, new_bucket: i64) {
        let Some(prev) = self.last_bucket else {
            self.clear_column((new_bucket.rem_euclid(self.tex_w as i64)) as u32);
            self.last_bucket = Some(new_bucket);
            return;
        };

        if new_bucket <= prev {
            return;
        }

        let jump = new_bucket - prev;
        let w = self.tex_w as i64;
        let max_steps = self.tex_w as i64;

        if jump > max_steps {
            self.clear_all();
            self.last_bucket = Some(new_bucket);
            return;
        }

        // Missing buckets between two observed updates are carried forward from the
        // previous observation.
        // TODO: Stream-level stall/disconnect should be handled above
        // this layer and force a state reset when continuity is not trustworthy.
        let mut from_x = (prev.rem_euclid(w)) as u32;

        let end_excl = new_bucket; // IMPORTANT: exclude new_bucket itself
        for b in (prev + 1)..end_excl {
            let to_x = (b.rem_euclid(w)) as u32;
            self.copy_column(from_x, to_x);
            from_x = to_x;
        }

        self.last_bucket = Some(new_bucket);
    }

    /// Build a renderer upload from the ring's dirty flags.
    fn build_scene_upload(&mut self) -> Option<super::HeatmapUpload> {
        if self.tex_w == 0 || self.tex_h == 0 {
            return None;
        }

        if self.take_full_dirty() {
            return Some(super::HeatmapUpload::Full {
                width: self.tex_w,
                height: self.tex_h,
                bid: Arc::from(self.bid.clone()),
                ask: Arc::from(self.ask.clone()),
            });
        }

        let xs = self.drain_dirty_columns();
        if xs.is_empty() {
            return None;
        }

        let mut cols: Vec<super::HeatmapColumnCpu> = Vec::with_capacity(xs.len());
        for x in xs {
            cols.push(super::HeatmapColumnCpu {
                x,
                bid_col: Arc::from(self.extract_bid_column(x)),
                ask_col: Arc::from(self.extract_ask_column(x)),
            });
        }

        Some(super::HeatmapUpload::Cols {
            width: self.tex_w,
            height: self.tex_h,
            cols: Arc::from(cols),
        })
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct HeatmapPalette {
    pub bid_rgb: [f32; 3],
    pub ask_rgb: [f32; 3],
    pub buy_rgb: [f32; 3],
    pub sell_rgb: [f32; 3],
    pub secondary_rgb: [f32; 3],
}

impl HeatmapPalette {
    pub fn from_theme(theme: &iced_core::Theme) -> Self {
        let palette = theme.extended_palette();

        let bid = palette.success.strong.color;
        let bid_linear = Self::srgb_to_linear([bid.r, bid.g, bid.b]);

        let ask = palette.danger.strong.color;
        let ask_linear = Self::srgb_to_linear([ask.r, ask.g, ask.b]);

        let buy = palette.success.base.color;
        let buy_linear = Self::srgb_to_linear([buy.r, buy.g, buy.b]);
        let sell = palette.danger.base.color;
        let sell_linear = Self::srgb_to_linear([sell.r, sell.g, sell.b]);

        let secondary = palette.secondary.base.color;
        let secondary_linear = Self::srgb_to_linear([secondary.r, secondary.g, secondary.b]);

        Self {
            bid_rgb: bid_linear,
            ask_rgb: ask_linear,
            buy_rgb: buy_linear,
            sell_rgb: sell_linear,
            secondary_rgb: secondary_linear,
        }
    }

    #[inline]
    fn srgb_to_linear_channel(u: f32) -> f32 {
        if u <= 0.04045 {
            u / 12.92
        } else {
            ((u + 0.055) / 1.055).powf(2.4)
        }
    }

    #[inline]
    fn srgb_to_linear(rgb: [f32; 3]) -> [f32; 3] {
        [
            Self::srgb_to_linear_channel(rgb[0]),
            Self::srgb_to_linear_channel(rgb[1]),
            Self::srgb_to_linear_channel(rgb[2]),
        ]
    }
}
