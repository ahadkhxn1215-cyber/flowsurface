pub mod circle;
pub mod rectangle;

use super::HeatmapColumnCpu;
use super::camera::CameraUniform;
use super::drain_dropped_scene_ids;
use super::uniform::{GpuUniforms, ParamsUniform};
use circle::{CIRCLE_INDICES, CIRCLE_VERTICES, CircleInstance};
use rectangle::{RECT_INDICES, RECT_VERTICES, RectInstance};

use iced::wgpu;
use iced::wgpu::PipelineCompilationOptions;
use iced::wgpu::util::DeviceExt;

use rustc_hash::FxHashMap;

pub(super) const RECT_SHADER_SRC: &str = concat!(
    include_str!("../shaders/common.wgsl"),
    "\n",
    include_str!("../shaders/rect.wgsl"),
);
const CIRCLE_SHADER_SRC: &str = concat!(
    include_str!("../shaders/common.wgsl"),
    "\n",
    include_str!("../shaders/circle.wgsl"),
);
const HEATMAP_SHADER_SRC: &str = concat!(
    include_str!("../shaders/common.wgsl"),
    "\n",
    include_str!("../shaders/heatmap_tex.wgsl"),
);

mod bind {
    pub const CAMERA_GROUP: u32 = 0;

    pub const HEATMAP_GROUP: u32 = 1;
    pub const HEATMAP_TEX_BINDING: u32 = 0;
}

const CAMERA_UNIFORM_BYTES: usize = 2 * 16; // 2 vec4<f32>
const PARAMS_UNIFORM_BYTES: usize = 8 * 16; // 8 vec4<f32>

// Compile-time guarantees (fail build immediately on mismatch)
const _: [(); CAMERA_UNIFORM_BYTES] = [(); std::mem::size_of::<CameraUniform>()];
const _: [(); PARAMS_UNIFORM_BYTES] = [(); std::mem::size_of::<ParamsUniform>()];

#[inline]
fn validate_host_layouts() {
    debug_assert_eq!(std::mem::size_of::<CameraUniform>(), CAMERA_UNIFORM_BYTES);
    debug_assert_eq!(std::mem::size_of::<ParamsUniform>(), PARAMS_UNIFORM_BYTES);
}

#[derive(Copy, Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct DrawLayer(pub i16);

impl DrawLayer {
    pub const HEATMAP: Self = Self(0);
    pub const DEPTH_PROFILE: Self = Self(10);
    pub const CIRCLES: Self = Self(20);
    pub const VOLUME: Self = Self(30);
    pub const VOLUME_PROFILE: Self = Self(40);
}

#[derive(Copy, Clone, Debug)]
pub enum DrawOp {
    Heatmap,
    Rects { start: u32, count: u32 },
    Circles { start: u32, count: u32 },
}

#[derive(Copy, Clone, Debug)]
pub struct DrawItem {
    pub layer: DrawLayer,
    pub op: DrawOp,
}

impl DrawItem {
    #[inline]
    pub fn new(layer: DrawLayer, op: DrawOp) -> Self {
        Self { layer, op }
    }
}

struct PerSceneGpu {
    rect_instance_buffer: wgpu::Buffer,
    rect_instance_capacity: usize,
    rect_uploaded_gen: u64,

    circle_instance_buffer: wgpu::Buffer,
    circle_instance_capacity: usize,
    circle_uploaded_gen: u64,

    uniforms: GpuUniforms,

    heatmap_tex: wgpu::Texture,
    heatmap_view: wgpu::TextureView,
    heatmap_tex_bind_group: wgpu::BindGroup,
    heatmap_tex_size: (u32, u32),
    heatmap_uploaded_gen: u64,
}

pub struct Pipeline {
    rect_pipeline: wgpu::RenderPipeline,
    circle_pipeline: wgpu::RenderPipeline,

    heatmap_pipeline: wgpu::RenderPipeline,
    heatmap_vertex_buffer: wgpu::Buffer,
    heatmap_index_buffer: wgpu::Buffer,
    heatmap_num_indices: u32,
    heatmap_tex_bind_group_layout: wgpu::BindGroupLayout,

    rect_vertex_buffer: wgpu::Buffer,
    circle_vertex_buffer: wgpu::Buffer,

    rect_index_buffer: wgpu::Buffer,
    circle_index_buffer: wgpu::Buffer,

    camera_bind_group_layout: wgpu::BindGroupLayout,

    per_scene: FxHashMap<u64, PerSceneGpu>,
    heatmap_upload_scratch: Vec<u8>,

    rect_num_indices: u32,
    circle_num_indices: u32,
}

impl Pipeline {
    pub fn new(device: &wgpu::Device, _queue: &wgpu::Queue, format: wgpu::TextureFormat) -> Self {
        validate_host_layouts();

        // -- buffers
        let rect_vertex_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("rect vertex buffer"),
            contents: bytemuck::cast_slice(RECT_VERTICES),
            usage: wgpu::BufferUsages::VERTEX,
        });
        let rect_index_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("rect index buffer"),
            contents: bytemuck::cast_slice(RECT_INDICES),
            usage: wgpu::BufferUsages::INDEX,
        });

        let circle_vertex_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("circle vertex buffer"),
            contents: bytemuck::cast_slice(CIRCLE_VERTICES),
            usage: wgpu::BufferUsages::VERTEX,
        });
        let circle_index_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("circle index buffer"),
            contents: bytemuck::cast_slice(CIRCLE_INDICES),
            usage: wgpu::BufferUsages::INDEX,
        });

        let circle_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            source: wgpu::ShaderSource::Wgsl(CIRCLE_SHADER_SRC.into()),
            label: Some("circle shader"),
        });
        let heatmap_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            source: wgpu::ShaderSource::Wgsl(HEATMAP_SHADER_SRC.into()),
            label: Some("heatmap texture shader"),
        });

        // -- bind groups
        let camera_bind_group_layout = GpuUniforms::bind_group_layout(device);

        let pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("heatmap pipeline layout"),
            bind_group_layouts: &[&camera_bind_group_layout],
            push_constant_ranges: &[],
        });

        let rect_pipeline = rectangle::pipeline(device, format, &camera_bind_group_layout);

        // -- circle pipeline
        let circle_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("circle pipeline"),
            layout: Some(&pipeline_layout),
            vertex: wgpu::VertexState {
                module: &circle_shader,
                entry_point: Some("vs_main"),
                buffers: &[
                    wgpu::VertexBufferLayout {
                        array_stride: std::mem::size_of::<[f32; 2]>() as u64,
                        step_mode: wgpu::VertexStepMode::Vertex,
                        attributes: &[wgpu::VertexAttribute {
                            offset: 0,
                            shader_location: 0,
                            format: wgpu::VertexFormat::Float32x2,
                        }],
                    },
                    wgpu::VertexBufferLayout {
                        array_stride: std::mem::size_of::<CircleInstance>() as u64,
                        step_mode: wgpu::VertexStepMode::Instance,
                        attributes: &[
                            // @location(1) y_world: f32
                            wgpu::VertexAttribute {
                                offset: 0,
                                shader_location: 1,
                                format: wgpu::VertexFormat::Float32,
                            },
                            // @location(2) x_bin_rel: i32
                            wgpu::VertexAttribute {
                                offset: 4,
                                shader_location: 2,
                                format: wgpu::VertexFormat::Sint32,
                            },
                            // @location(3) x_frac: f32
                            wgpu::VertexAttribute {
                                offset: 8,
                                shader_location: 3,
                                format: wgpu::VertexFormat::Float32,
                            },
                            // @location(4) radius_px: f32
                            wgpu::VertexAttribute {
                                offset: 12,
                                shader_location: 4,
                                format: wgpu::VertexFormat::Float32,
                            },
                            // @location(5) color: vec4<f32>
                            wgpu::VertexAttribute {
                                offset: 20,
                                shader_location: 5,
                                format: wgpu::VertexFormat::Float32x4,
                            },
                        ],
                    },
                ],
                compilation_options: PipelineCompilationOptions::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &circle_shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format,
                    blend: Some(wgpu::BlendState::PREMULTIPLIED_ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: PipelineCompilationOptions::default(),
            }),
            primitive: wgpu::PrimitiveState::default(),
            depth_stencil: None,
            multisample: wgpu::MultisampleState::default(),
            multiview: None,
            cache: None,
        });

        let heatmap_vertex_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("heatmap quad vertex buffer"),
            contents: bytemuck::cast_slice(RECT_VERTICES),
            usage: wgpu::BufferUsages::VERTEX,
        });
        let heatmap_index_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("heatmap quad index buffer"),
            contents: bytemuck::cast_slice(RECT_INDICES),
            usage: wgpu::BufferUsages::INDEX,
        });
        let heatmap_num_indices = RECT_INDICES.len() as u32;

        let heatmap_tex_bind_group_layout =
            device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: Some("heatmap texture bind group layout (u32 bid+ask packed RG)"),
                entries: &[wgpu::BindGroupLayoutEntry {
                    binding: bind::HEATMAP_TEX_BINDING,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Uint,
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                }],
            });

        let heatmap_pipeline_layout =
            device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: Some("heatmap texture pipeline layout"),
                bind_group_layouts: &[&camera_bind_group_layout, &heatmap_tex_bind_group_layout],
                push_constant_ranges: &[],
            });

        let heatmap_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("heatmap texture pipeline"),
            layout: Some(&heatmap_pipeline_layout),
            vertex: wgpu::VertexState {
                module: &heatmap_shader,
                entry_point: Some("vs_main"),
                buffers: &[wgpu::VertexBufferLayout {
                    array_stride: std::mem::size_of::<[f32; 2]>() as u64,
                    step_mode: wgpu::VertexStepMode::Vertex,
                    attributes: &[wgpu::VertexAttribute {
                        offset: 0,
                        shader_location: 0,
                        format: wgpu::VertexFormat::Float32x2,
                    }],
                }],
                compilation_options: PipelineCompilationOptions::default(),
            },
            fragment: Some(wgpu::FragmentState {
                module: &heatmap_shader,
                entry_point: Some("fs_main"),
                targets: &[Some(wgpu::ColorTargetState {
                    format,
                    blend: Some(wgpu::BlendState::PREMULTIPLIED_ALPHA_BLENDING),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: PipelineCompilationOptions::default(),
            }),
            primitive: wgpu::PrimitiveState::default(),
            depth_stencil: None,
            multisample: wgpu::MultisampleState::default(),
            multiview: None,
            cache: None,
        });

        Self {
            rect_pipeline,
            circle_pipeline,
            rect_vertex_buffer,
            circle_vertex_buffer,
            rect_index_buffer,
            circle_index_buffer,
            camera_bind_group_layout,
            per_scene: FxHashMap::default(),
            heatmap_upload_scratch: Vec::new(),
            rect_num_indices: RECT_INDICES.len() as u32,
            circle_num_indices: CIRCLE_INDICES.len() as u32,
            heatmap_pipeline,
            heatmap_vertex_buffer,
            heatmap_index_buffer,
            heatmap_num_indices,
            heatmap_tex_bind_group_layout,
        }
    }

    pub fn update_params(
        &mut self,
        id: u64,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        params: &ParamsUniform,
    ) {
        self.ensure_scene(id, device)
            .uniforms
            .update_params(queue, params);
    }

    fn ensure_scene(&mut self, id: u64, device: &wgpu::Device) -> &mut PerSceneGpu {
        self.per_scene.entry(id).or_insert_with(|| {
            let rect_instance_capacity: usize = 4096;
            let rect_instance_buffer = device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("rect instance buffer"),
                size: (rect_instance_capacity * std::mem::size_of::<RectInstance>()) as u64,
                usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            });

            let circle_instance_capacity: usize = 4096;
            let circle_instance_buffer = device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("circle instance buffer"),
                size: (circle_instance_capacity * std::mem::size_of::<CircleInstance>()) as u64,
                usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            });

            let uniforms = GpuUniforms::new(
                device,
                &self.camera_bind_group_layout,
                CameraUniform {
                    a: [1.0, 1.0, 0.0, 0.0],
                    b: [1.0, 1.0, 0.0, 0.0],
                },
                ParamsUniform::default(),
            );

            let heatmap_tex = device.create_texture(&wgpu::TextureDescriptor {
                label: Some("heatmap tex (init)"),
                size: wgpu::Extent3d {
                    width: 1,
                    height: 1,
                    depth_or_array_layers: 1,
                },
                mip_level_count: 1,
                sample_count: 1,
                dimension: wgpu::TextureDimension::D2,
                format: wgpu::TextureFormat::Rg32Uint,
                usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
                view_formats: &[],
            });
            let heatmap_view = heatmap_tex.create_view(&wgpu::TextureViewDescriptor::default());

            let heatmap_tex_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: Some("heatmap tex bind group (u32 bid+ask packed RG)"),
                layout: &self.heatmap_tex_bind_group_layout,
                entries: &[wgpu::BindGroupEntry {
                    binding: bind::HEATMAP_TEX_BINDING,
                    resource: wgpu::BindingResource::TextureView(&heatmap_view),
                }],
            });

            PerSceneGpu {
                rect_instance_buffer,
                rect_instance_capacity,
                rect_uploaded_gen: 0,

                circle_instance_buffer,
                circle_instance_capacity,
                circle_uploaded_gen: 0,

                uniforms,

                heatmap_tex,
                heatmap_view,
                heatmap_tex_bind_group,
                heatmap_tex_size: (1, 1),
                heatmap_uploaded_gen: 0,
            }
        })
    }

    pub(super) fn cleanup_dropped_scenes(&mut self) {
        for id in drain_dropped_scene_ids() {
            self.per_scene.remove(&id);
        }
    }

    pub fn trim_pipeline_cache(&mut self) {
        self.cleanup_dropped_scenes();

        if self.per_scene.is_empty() {
            self.heatmap_upload_scratch.clear();
            self.heatmap_upload_scratch.shrink_to_fit();
        }
    }

    pub fn update_rect_instances(
        &mut self,
        id: u64,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        instances: &[RectInstance],
        generation: u64,
    ) {
        let gpu = self.ensure_scene(id, device);

        if generation == gpu.rect_uploaded_gen {
            return;
        }

        if instances.is_empty() {
            gpu.rect_uploaded_gen = generation;
            return;
        }

        if instances.len() > gpu.rect_instance_capacity {
            gpu.rect_instance_capacity = instances.len().next_power_of_two();
            gpu.rect_instance_buffer = device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("rect instance buffer (resized)"),
                size: (gpu.rect_instance_capacity * std::mem::size_of::<RectInstance>()) as u64,
                usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            });
        }

        queue.write_buffer(
            &gpu.rect_instance_buffer,
            0,
            bytemuck::cast_slice(instances),
        );
        gpu.rect_uploaded_gen = generation;
    }

    pub fn update_circle_instances(
        &mut self,
        id: u64,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        instances: &[CircleInstance],
        generation: u64,
    ) {
        let gpu = self.ensure_scene(id, device);

        if generation == gpu.circle_uploaded_gen {
            return;
        }

        if instances.is_empty() {
            gpu.circle_uploaded_gen = generation;
            return;
        }

        if instances.len() > gpu.circle_instance_capacity {
            gpu.circle_instance_capacity = instances.len().next_power_of_two();
            gpu.circle_instance_buffer = device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("circle instance buffer (resized)"),
                size: (gpu.circle_instance_capacity * std::mem::size_of::<CircleInstance>()) as u64,
                usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            });
        }

        queue.write_buffer(
            &gpu.circle_instance_buffer,
            0,
            bytemuck::cast_slice(instances),
        );
        gpu.circle_uploaded_gen = generation;
    }

    pub fn update_heatmap_columns_u32(
        &mut self,
        id: u64,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        width: u32,
        height: u32,
        heatmap_cols: &[HeatmapColumnCpu],
        generation: u64,
    ) {
        {
            let gpu = self.ensure_scene(id, device);
            if generation == gpu.heatmap_uploaded_gen {
                return;
            }
            if width == 0 || height == 0 {
                return;
            }
        }

        let needs_resize = {
            let gpu = self.per_scene.get(&id).unwrap();
            gpu.heatmap_tex_size != (width, height)
        };
        if needs_resize {
            self.resize_heatmap_textures_u32(id, device, width, height);
        }

        let heatmap_tex = self.per_scene.get(&id).unwrap().heatmap_tex.clone();

        for col in heatmap_cols {
            let x = col.x;
            debug_assert!(x < width);
            debug_assert_eq!(col.bid_col.len(), height as usize);
            debug_assert_eq!(col.ask_col.len(), height as usize);

            Self::write_rg32u_texture_column(
                queue,
                &heatmap_tex,
                x,
                height,
                col.bid_col.as_ref(),
                col.ask_col.as_ref(),
                &mut self.heatmap_upload_scratch,
            );
        }

        let gpu = self.per_scene.get_mut(&id).unwrap();
        gpu.heatmap_uploaded_gen = generation;
    }

    pub fn update_heatmap_textures_u32(
        &mut self,
        id: u64,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        width: u32,
        height: u32,
        bid_col_u32: &[u32], // len == width*height
        ask_col_u32: &[u32], // len == width*height
        generation: u64,
    ) {
        {
            let gpu = self.ensure_scene(id, device);
            if generation == gpu.heatmap_uploaded_gen {
                return;
            }
            if width == 0 || height == 0 {
                return;
            }
        }

        debug_assert_eq!(bid_col_u32.len(), (width * height) as usize);
        debug_assert_eq!(ask_col_u32.len(), (width * height) as usize);

        let needs_resize = {
            let gpu = self.per_scene.get(&id).unwrap();
            gpu.heatmap_tex_size != (width, height)
        };
        if needs_resize {
            self.resize_heatmap_textures_u32(id, device, width, height);
        }

        let heatmap_tex = self.per_scene.get(&id).unwrap().heatmap_tex.clone();

        Self::write_rg32u_texture_full(
            queue,
            &heatmap_tex,
            width,
            height,
            bid_col_u32,
            ask_col_u32,
            &mut self.heatmap_upload_scratch,
        );

        let gpu = self.per_scene.get_mut(&id).unwrap();
        gpu.heatmap_uploaded_gen = generation;
    }

    #[inline]
    fn put_u32_le(dst: &mut [u8], off: usize, v: u32) {
        dst[off..off + 4].copy_from_slice(&v.to_le_bytes());
    }

    fn write_rg32u_texture_column(
        queue: &wgpu::Queue,
        tex: &wgpu::Texture,
        origin_x: u32,
        height: u32,
        bid_col: &[u32], // len == height
        ask_col: &[u32], // len == height
        scratch: &mut Vec<u8>,
    ) {
        // 1 texel wide, RG32Uint => 8 bytes per row minimum.
        let unpadded_bpr: usize = 8;
        let padded_bpr = (unpadded_bpr + 255) & !255;

        let needed = padded_bpr * (height as usize);
        if scratch.len() < needed {
            scratch.resize(needed, 0u8);
        }
        let staging = &mut scratch[..needed];

        for y in 0..(height as usize) {
            let dst_off = y * padded_bpr;
            Self::put_u32_le(staging, dst_off, bid_col[y]);
            Self::put_u32_le(staging, dst_off + 4, ask_col[y]);
        }

        queue.write_texture(
            wgpu::TexelCopyTextureInfo {
                texture: tex,
                mip_level: 0,
                origin: wgpu::Origin3d {
                    x: origin_x,
                    y: 0,
                    z: 0,
                },
                aspect: wgpu::TextureAspect::All,
            },
            staging,
            wgpu::TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(padded_bpr as u32),
                rows_per_image: Some(height),
            },
            wgpu::Extent3d {
                width: 1,
                height,
                depth_or_array_layers: 1,
            },
        );
    }

    fn write_rg32u_texture_full(
        queue: &wgpu::Queue,
        tex: &wgpu::Texture,
        width: u32,
        height: u32,
        bid: &[u32], // len == width*height
        ask: &[u32], // len == width*height
        scratch: &mut Vec<u8>,
    ) {
        let w = width as usize;
        let h = height as usize;

        // Each texel is 8 bytes (bid u32 + ask u32).
        let unpadded_bpr: usize = w * 8;
        let padded_bpr: usize = (unpadded_bpr + 255) & !255;

        let needed = padded_bpr * h;
        if scratch.len() < needed {
            scratch.resize(needed, 0u8);
        }
        let staging = &mut scratch[..needed];

        for y in 0..h {
            let row_dst = y * padded_bpr;
            let row_src = y * w;
            for x in 0..w {
                let i = row_src + x;
                let dst_off = row_dst + x * 8;
                Self::put_u32_le(staging, dst_off, bid[i]);
                Self::put_u32_le(staging, dst_off + 4, ask[i]);
            }
        }

        queue.write_texture(
            wgpu::TexelCopyTextureInfo {
                texture: tex,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            staging,
            wgpu::TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(padded_bpr as u32),
                rows_per_image: Some(height),
            },
            wgpu::Extent3d {
                width,
                height,
                depth_or_array_layers: 1,
            },
        );
    }

    fn resize_heatmap_textures_u32(
        &mut self,
        id: u64,
        device: &wgpu::Device,
        width: u32,
        height: u32,
    ) {
        let gpu = self.per_scene.get_mut(&id).unwrap();
        let layout = &self.heatmap_tex_bind_group_layout;

        gpu.heatmap_tex = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("heatmap tex"),
            size: wgpu::Extent3d {
                width,
                height,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Rg32Uint,
            usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
            view_formats: &[],
        });
        gpu.heatmap_view = gpu
            .heatmap_tex
            .create_view(&wgpu::TextureViewDescriptor::default());

        gpu.heatmap_tex_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("heatmap tex bind group (resized u32 bid+ask packed RG)"),
            layout,
            entries: &[wgpu::BindGroupEntry {
                binding: bind::HEATMAP_TEX_BINDING,
                resource: wgpu::BindingResource::TextureView(&gpu.heatmap_view),
            }],
        });

        gpu.heatmap_tex_size = (width, height);
    }

    pub fn update_camera(
        &mut self,
        id: u64,
        device: &wgpu::Device,
        queue: &wgpu::Queue,
        camera: &CameraUniform,
    ) {
        self.ensure_scene(id, device)
            .uniforms
            .update_camera(queue, camera);
    }

    pub fn draw_ordered(
        &self,
        id: u64,
        pass: &mut wgpu::RenderPass<'_>,
        rect_total_instances: u32,
        circle_total_instances: u32,
        draw_list: &[DrawItem],
    ) {
        let Some(gpu) = self.per_scene.get(&id) else {
            return;
        };

        pass.set_bind_group(bind::CAMERA_GROUP, &gpu.uniforms.bind_group, &[]);

        let rect_stride = std::mem::size_of::<RectInstance>() as u64;
        let circle_stride = std::mem::size_of::<CircleInstance>() as u64;

        for item in draw_list {
            match item.op {
                DrawOp::Heatmap => {
                    pass.set_pipeline(&self.heatmap_pipeline);
                    pass.set_bind_group(bind::HEATMAP_GROUP, &gpu.heatmap_tex_bind_group, &[]);
                    pass.set_vertex_buffer(0, self.heatmap_vertex_buffer.slice(..));
                    pass.set_index_buffer(
                        self.heatmap_index_buffer.slice(..),
                        wgpu::IndexFormat::Uint16,
                    );
                    pass.draw_indexed(0..self.heatmap_num_indices, 0, 0..1);
                }
                DrawOp::Rects { start, count } => {
                    let start = start.min(rect_total_instances);
                    let count = count.min(rect_total_instances.saturating_sub(start));
                    if count == 0 {
                        continue;
                    }

                    let a = (start as u64) * rect_stride;
                    let b = a + (count as u64) * rect_stride;

                    pass.set_pipeline(&self.rect_pipeline);
                    pass.set_vertex_buffer(0, self.rect_vertex_buffer.slice(..));
                    pass.set_vertex_buffer(1, gpu.rect_instance_buffer.slice(a..b));
                    pass.set_index_buffer(
                        self.rect_index_buffer.slice(..),
                        wgpu::IndexFormat::Uint16,
                    );
                    pass.draw_indexed(0..self.rect_num_indices, 0, 0..count);
                }
                DrawOp::Circles { start, count } => {
                    let start = start.min(circle_total_instances);
                    let count = count.min(circle_total_instances.saturating_sub(start));
                    if count == 0 {
                        continue;
                    }

                    let a = (start as u64) * circle_stride;
                    let b = a + (count as u64) * circle_stride;

                    pass.set_pipeline(&self.circle_pipeline);
                    pass.set_vertex_buffer(0, self.circle_vertex_buffer.slice(..));
                    pass.set_vertex_buffer(1, gpu.circle_instance_buffer.slice(a..b));
                    pass.set_index_buffer(
                        self.circle_index_buffer.slice(..),
                        wgpu::IndexFormat::Uint16,
                    );
                    pass.draw_indexed(0..self.circle_num_indices, 0, 0..count);
                }
            }
        }
    }
}
