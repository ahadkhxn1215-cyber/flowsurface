use super::AxisInteraction;
use crate::widget::chart::Y_AXIS_LABEL_LEFT_INSET;
use crate::widget::chart::heatmap::{Message, scene::camera::Camera, ui::AXIS_TEXT_SIZE};
use data::chart::ticks::y::{PriceAxis, TickValue};
use exchange::unit::{MinTicksize, Price, PriceStep};
use iced::{Rectangle, Renderer, Theme, widget::canvas};
use iced_core::mouse;

/// Rough vertical spacing (in screen pixels) between Y-axis labels.
const LABEL_TARGET_PX: f32 = 48.0;
const DRAG_ZOOM_SENS: f32 = 0.004;

pub struct AxisYLabelCanvas<'a> {
    pub cache: &'a iced::widget::canvas::Cache,
    pub plot_bounds: Option<Rectangle>,
    pub is_paused: bool,
    pub camera: &'a Camera,
    pub base_price: Option<Price>,
    pub step: PriceStep,
    pub row_h: f32,
    /// Rounds/formats labels to a decade step (e.g. power=-2 => 0.01).
    pub label_precision: MinTicksize,
}

/// Represents a label to be drawn on the Y axis.
enum LabelKind {
    Tick { y_px: f32, label: String },
    Base { y_px: f32, label: String },
    Cursor { y_px: f32, label: String },
}

impl LabelKind {
    fn clip_range(&self, label_height: f32) -> (f32, f32) {
        match self {
            LabelKind::Tick { y_px, .. }
            | LabelKind::Base { y_px, .. }
            | LabelKind::Cursor { y_px, .. } => {
                (*y_px - 0.5 * label_height, *y_px + 0.5 * label_height)
            }
        }
    }
}

impl AxisYLabelCanvas<'_> {
    fn world_to_px_y(&self, y_world: f32, bounds: Rectangle) -> f32 {
        self.camera
            .world_to_screen_y(y_world, bounds.width, bounds.height)
    }

    fn px_to_world_y(&self, y_px: f32, bounds: Rectangle) -> f32 {
        self.camera
            .screen_to_world_y(y_px, bounds.width, bounds.height)
    }

    pub fn width(base_price: Option<Price>, label_precision: MinTicksize) -> Option<iced::Length> {
        let value = base_price?.to_string(label_precision);
        let width = (value.len() as f32 * AXIS_TEXT_SIZE * 0.8).max(72.0);

        Some(iced::Length::Fixed(width.ceil()))
    }
}

impl canvas::Program<Message> for AxisYLabelCanvas<'_> {
    type State = super::AxisState;

    fn update(
        &self,
        state: &mut Self::State,
        event: &iced::Event,
        bounds: Rectangle,
        cursor: mouse::Cursor,
    ) -> Option<canvas::Action<Message>> {
        match event {
            iced::Event::Mouse(mouse::Event::ButtonPressed(mouse::Button::Left)) => {
                let p = cursor.position_over(bounds)?;
                let click = mouse::Click::new(p, mouse::Button::Left, state.previous_click);
                state.previous_click = Some(click);

                if click.kind() == mouse::click::Kind::Double {
                    state.interaction = AxisInteraction::None;
                    return Some(canvas::Action::publish(Message::AxisYDoubleClicked));
                }

                state.interaction = AxisInteraction::Panning {
                    last_position: p,
                    zoom_anchor: None,
                };
                None
            }
            iced::Event::Mouse(mouse::Event::ButtonReleased(mouse::Button::Left)) => {
                state.interaction = AxisInteraction::None;
                None
            }
            iced::Event::Mouse(mouse::Event::CursorMoved { position }) => {
                if let AxisInteraction::Panning { last_position, .. } = &mut state.interaction {
                    let delta_px = *position - *last_position;
                    *last_position = *position;

                    let factor = (-delta_px.y * DRAG_ZOOM_SENS).exp().clamp(0.01, 100.0);

                    Some(canvas::Action::publish(Message::ScrolledAxisY {
                        factor,
                        cursor_y: bounds.height * 0.5, // anchor at viewport center
                        viewport_h: bounds.height,
                    }))
                } else {
                    None
                }
            }
            iced::Event::Mouse(mouse::Event::WheelScrolled { delta }) => {
                let p = cursor.position_in(bounds)?;

                Some(canvas::Action::publish(Message::ScrolledAxisY {
                    factor: super::wheel_zoom_factor(*delta),
                    cursor_y: p.y,
                    viewport_h: bounds.height,
                }))
            }
            _ => None,
        }
    }

    fn draw(
        &self,
        _state: &Self::State,
        renderer: &Renderer,
        theme: &Theme,
        bounds: Rectangle,
        cursor: mouse::Cursor,
    ) -> Vec<canvas::Geometry> {
        let cam_sy = self.camera.scale();
        if !self.row_h.is_finite() || self.row_h <= 0.0 || !cam_sy.is_finite() || cam_sy <= 0.0 {
            return vec![];
        }

        let Some(base_price) = self.base_price else {
            return vec![];
        };

        let palette = theme.extended_palette();

        let tick_labels = self.cache.draw(renderer, bounds.size(), |frame| {
            let row_h = self.row_h;

            let y_world_top = self.px_to_world_y(0.0, bounds);
            let y_world_bottom = self.px_to_world_y(bounds.height, bounds);

            let step = PriceStep {
                units: self.step.units.max(1),
            };
            let price_at_step = |offset: i64| {
                base_price
                    .checked_add_steps(offset, step)
                    .unwrap_or_else(|| {
                        Price::from_units(if offset.is_negative() {
                            i64::MIN
                        } else {
                            i64::MAX
                        })
                    })
            };

            let step_at_top = super::step_center_pos_from_world_y(y_world_top, row_h);
            let step_at_bottom = super::step_center_pos_from_world_y(y_world_bottom, row_h);

            let lowest_step = step_at_top.min(step_at_bottom).floor() as i64;
            let highest_step = step_at_top.max(step_at_bottom).ceil() as i64;

            let lowest_price = price_at_step(lowest_step);
            let highest_price = price_at_step(highest_step);

            let labels_can_fit = (bounds.height / LABEL_TARGET_PX).floor() as i32;

            // Universal row-aligned price grid (same machinery as the kline
            // chart); lives in `data::chart::ticks`. Fall back to a grid of
            // exactly the row step when no coarser "nice" grid fits.
            let axis = PriceAxis::new(step, Some(self.label_precision));
            let mut ticks = axis.ticks(
                lowest_price.to_f64(),
                highest_price.to_f64(),
                labels_can_fit,
            );
            if ticks.ticks.is_empty() {
                ticks = axis.ticks_from_row(lowest_price.to_f64(), highest_price.to_f64());
            }

            let x = Y_AXIS_LABEL_LEFT_INSET;
            let cursor_label_padding = 3.0f32;
            let cursor_label_height = AXIS_TEXT_SIZE + 2.0 * cursor_label_padding;
            let size_cursor_label = iced::Size {
                width: bounds.width,
                height: cursor_label_height,
            };

            // --- Compute label positions and values ---
            let mut labels: Vec<LabelKind> = Vec::new();

            let suppress_cursor_label =
                super::paused_control_hovered(self.is_paused, self.plot_bounds, cursor);

            // Cursor label (highest priority)
            let cursor_label_snapped = if suppress_cursor_label {
                None
            } else {
                self.plot_bounds
                    .and_then(|pb| cursor.position_in(pb))
                    .map(|p| {
                        let y_world_cursor = self.px_to_world_y(p.y, bounds);
                        let step_at_cursor =
                            super::step_center_pos_from_world_y(y_world_cursor, row_h).round()
                                as i64;
                        let y_world_for_step =
                            super::world_y_for_step_center(step_at_cursor, row_h);
                        let y_px = self.world_to_px_y(y_world_for_step, bounds);

                        let price_at_cursor = price_at_step(step_at_cursor);
                        let label_at_cursor = axis.format(price_at_cursor);

                        LabelKind::Cursor {
                            y_px,
                            label: label_at_cursor,
                        }
                    })
            };

            // Base price label (secondary priority)
            let base_step: i64 = 0;
            let y_world_base = super::world_y_for_step_center(base_step, row_h);
            let y_px_base = self.world_to_px_y(y_world_base, bounds);

            let price_base = price_at_step(base_step);
            let label_base = axis.format(price_base);

            let base_label = LabelKind::Base {
                y_px: y_px_base,
                label: label_base,
            };

            // Tick labels (absolute price-domain majors from the row grid)
            for tick in ticks.ticks {
                let TickValue::PriceUnits(tick_units) = tick.value else {
                    continue;
                };
                let rel_units = tick_units.saturating_sub(base_price.units);

                if rel_units % step.units == 0 {
                    let s = rel_units / step.units;
                    let y_world = super::world_y_for_step_center(s, row_h);
                    let y_px = self.world_to_px_y(y_world, bounds);

                    if (0.0..=bounds.height).contains(&y_px) {
                        let label = axis.format_units(tick_units);
                        labels.push(LabelKind::Tick { y_px, label });
                    }
                }
            }

            // --- Render labels with overlap filtering ---
            let text_color = palette.background.base.text;

            // Compute clip ranges for cursor and base labels
            let cursor_clip_range = cursor_label_snapped
                .as_ref()
                .map(|l| l.clip_range(size_cursor_label.height));
            let base_clip_range = base_label.clip_range(size_cursor_label.height);

            // Draw tick labels, skipping overlaps
            for label in &labels {
                let tick_clip = label.clip_range(AXIS_TEXT_SIZE * 0.7 * 2.0);
                // Skip if overlaps cursor or base label
                if cursor_clip_range.is_some_and(|c| ranges_overlap(tick_clip, c)) {
                    continue;
                }
                if ranges_overlap(tick_clip, base_clip_range) {
                    continue;
                }

                if let LabelKind::Tick { y_px, label } = label {
                    frame.fill_text(canvas::Text {
                        content: label.clone(),
                        position: iced::Point::new(x, *y_px),
                        color: text_color,
                        size: AXIS_TEXT_SIZE.into(),
                        font: crate::style::AZERET_MONO,
                        align_x: iced::Alignment::Start.into(),
                        align_y: iced::Alignment::Center.into(),
                        ..Default::default()
                    });
                }
            }

            // Draw base label if not overlapped by cursor
            let base_y_in_view = (0.0..=bounds.height).contains(&y_px_base);
            let overlaps_cursor = cursor_clip_range
                .map(|c| ranges_overlap(base_clip_range, c))
                .unwrap_or(false);
            if base_y_in_view && !overlaps_cursor {
                let mut bg = palette.secondary.strong.color;
                bg = iced::Color { a: 1.0, ..bg };

                frame.fill_rectangle(
                    iced::Point::new(0.0, y_px_base - 0.5 * size_cursor_label.height),
                    size_cursor_label,
                    bg,
                );

                if let LabelKind::Base { label, .. } = &base_label {
                    frame.fill_text(canvas::Text {
                        content: label.clone(),
                        position: iced::Point::new(x, y_px_base),
                        color: palette.primary.strong.text,
                        size: AXIS_TEXT_SIZE.into(),
                        font: crate::style::AZERET_MONO,
                        align_x: iced::Alignment::Start.into(),
                        align_y: iced::Alignment::Center.into(),
                        ..Default::default()
                    });
                }
            }

            // Draw cursor label (highest priority)
            if let Some(LabelKind::Cursor { y_px, label }) = cursor_label_snapped {
                let label_y = (y_px - 0.5 * size_cursor_label.height)
                    .clamp(0.0, (bounds.height - size_cursor_label.height).max(0.0));

                frame.fill_rectangle(
                    iced::Point::new(0.0, label_y),
                    size_cursor_label,
                    palette.background.strong.color,
                );

                frame.fill_text(canvas::Text {
                    content: label,
                    position: iced::Point::new(x, label_y + 0.5 * size_cursor_label.height),
                    color: palette.background.strong.text,
                    size: AXIS_TEXT_SIZE.into(),
                    font: crate::style::AZERET_MONO,
                    align_x: iced::Alignment::Start.into(),
                    align_y: iced::Alignment::Center.into(),
                    ..Default::default()
                });
            }
        });

        vec![tick_labels]
    }

    fn mouse_interaction(
        &self,
        state: &Self::State,
        bounds: Rectangle,
        cursor: mouse::Cursor,
    ) -> mouse::Interaction {
        if cursor.position_over(bounds).is_some() {
            match state.interaction {
                AxisInteraction::Panning { .. } => mouse::Interaction::Grabbing,
                _ => mouse::Interaction::ResizingVertically,
            }
        } else {
            mouse::Interaction::default()
        }
    }
}

fn ranges_overlap(a: (f32, f32), b: (f32, f32)) -> bool {
    a.1 >= b.0 && a.0 <= b.1
}
